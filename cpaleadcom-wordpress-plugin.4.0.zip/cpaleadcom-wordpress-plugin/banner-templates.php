
		var default_html_code = '<div class=\"cpalead-offers\">\n';
		default_html_code += '\t<div class=\"cpalead-offers-row\">\n';
		default_html_code += '\t\t<a href=\"{offer_link}\" target=\"_blank\">\n';
		default_html_code += '\t\t\t<div class=\"cpalead-offer\">\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-image\">\n';
		default_html_code += '\t\t\t\t\t<img src=\"{offer_image}\">\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-content\">\n';
		default_html_code += '\t\t\t\t\t<h3>{offer_title}</h3>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_1}</p>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_2}</p>\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t</div>\n';
		default_html_code += '\t\t</a>\n';
		default_html_code += '\t\t<a href=\"{offer_link}\" target=\"_blank\">\n';
		default_html_code += '\t\t\t<div class=\"cpalead-offer\">\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-image\">\n';
		default_html_code += '\t\t\t\t\t<img src=\"{offer_image}\">\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-content\">\n';
		default_html_code += '\t\t\t\t\t<h3>{offer_title}</h3>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_1}</p>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_2}</p>\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t</div>\n';
		default_html_code += '\t\t</a>\n';
		default_html_code += '\t\t<a href=\"{offer_link}\" target=\"_blank\">\n';
		default_html_code += '\t\t\t<div class=\"cpalead-offer\">\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-image\">\n';
		default_html_code += '\t\t\t\t\t<img src=\"{offer_image}\">\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-content\">\n';
		default_html_code += '\t\t\t\t\t<h3>{offer_title}</h3>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_1}</p>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_2}</p>\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t</div>\n';
		default_html_code += '\t\t</a>\n';
		default_html_code += '\t</div>\n';
		default_html_code += '\t<div class=\"cpalead-offers-row\">\n';
		default_html_code += '\t\t<a href=\"{offer_link}\" target=\"_blank\">\n';
		default_html_code += '\t\t\t<div class=\"cpalead-offer\">\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-image\">\n';
		default_html_code += '\t\t\t\t\t<img src=\"{offer_image}\">\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-content\">\n';
		default_html_code += '\t\t\t\t\t<h3>{offer_title}</h3>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_1}</p>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_2}</p>\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t</div>\n';
		default_html_code += '\t\t</a>\n';
		default_html_code += '\t\t<a href=\"{offer_link}\" target=\"_blank\">\n';
		default_html_code += '\t\t\t<div class=\"cpalead-offer\">\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-image\">\n';
		default_html_code += '\t\t\t\t\t<img src=\"{offer_image}\">\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-content\">\n';
		default_html_code += '\t\t\t\t\t<h3>{offer_title}</h3>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_1}</p>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_2}</p>\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t</div>\n';
		default_html_code += '\t\t</a>\n';
		default_html_code += '\t\t<a href=\"{offer_link}\" target=\"_blank\">\n';
		default_html_code += '\t\t\t<div class=\"cpalead-offer\">\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-image\">\n';
		default_html_code += '\t\t\t\t\t<img src=\"{offer_image}\">\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-content\">\n';
		default_html_code += '\t\t\t\t\t<h3>{offer_title}</h3>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_1}</p>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_2}</p>\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t</div>\n';
		default_html_code += '\t\t</a>\n';
		default_html_code += '\t</div>\n';
		default_html_code += '\t<div class=\"cpalead-offers-row\">\n';
		default_html_code += '\t\t<a href=\"{offer_link}\" target=\"_blank\">\n';
		default_html_code += '\t\t\t<div class=\"cpalead-offer\">\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-image\">\n';
		default_html_code += '\t\t\t\t\t<img src=\"{offer_image}\">\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-content\">\n';
		default_html_code += '\t\t\t\t\t<h3>{offer_title}</h3>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_1}</p>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_2}</p>\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t</div>\n';
		default_html_code += '\t\t</a>\n';
		default_html_code += '\t\t<a href=\"{offer_link}\" target=\"_blank\">\n';
		default_html_code += '\t\t\t<div class=\"cpalead-offer\">\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-image\">\n';
		default_html_code += '\t\t\t\t\t<img src=\"{offer_image}\">\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-content\">\n';
		default_html_code += '\t\t\t\t\t<h3>{offer_title}</h3>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_1}</p>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_2}</p>\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t</div>\n';
		default_html_code += '\t\t</a>\n';
		default_html_code += '\t\t<a href=\"{offer_link}\" target=\"_blank\">\n';
		default_html_code += '\t\t\t<div class=\"cpalead-offer\">\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-image\">\n';
		default_html_code += '\t\t\t\t\t<img src=\"{offer_image}\">\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-content\">\n';
		default_html_code += '\t\t\t\t\t<h3>{offer_title}</h3>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_1}</p>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_2}</p>\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t</div>\n';
		default_html_code += '\t\t</a>\n';
		default_html_code += '\t</div>\n';
		default_html_code += '\t<div class=\"cpalead-offers-row\">\n';
		default_html_code += '\t\t<a href=\"{offer_link}\" target=\"_blank\">\n';
		default_html_code += '\t\t\t<div class=\"cpalead-offer\">\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-image\">\n';
		default_html_code += '\t\t\t\t\t<img src=\"{offer_image}\">\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-content\">\n';
		default_html_code += '\t\t\t\t\t<h3>{offer_title}</h3>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_1}</p>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_2}</p>\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t</div>\n';
		default_html_code += '\t\t</a>\n';
		default_html_code += '\t\t<a href=\"{offer_link}\" target=\"_blank\">\n';
		default_html_code += '\t\t\t<div class=\"cpalead-offer\">\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-image\">\n';
		default_html_code += '\t\t\t\t\t<img src=\"{offer_image}\">\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-content\">\n';
		default_html_code += '\t\t\t\t\t<h3>{offer_title}</h3>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_1}</p>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_2}</p>\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t</div>\n';
		default_html_code += '\t\t</a>\n';
		default_html_code += '\t\t<a href=\"{offer_link}\" target=\"_blank\">\n';
		default_html_code += '\t\t\t<div class=\"cpalead-offer\">\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-image\">\n';
		default_html_code += '\t\t\t\t\t<img src=\"{offer_image}\">\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t\t<div class=\"cpalead-offer-content\">\n';
		default_html_code += '\t\t\t\t\t<h3>{offer_title}</h3>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_1}</p>\n';
		default_html_code += '\t\t\t\t\t<p>{offer_description_2}</p>\n';
		default_html_code += '\t\t\t\t</div>\n';
		default_html_code += '\t\t\t</div>\n';
		default_html_code += '\t\t</a>\n';
		default_html_code += '\t</div>\n';
		default_html_code += '</div>';

		var default_css_code = 'body {\n';
		default_css_code += '\tbackground-color: #fff;\n';
		default_css_code += '}\n';
		default_css_code += '\n';
		default_css_code += '.title {\n';
		default_css_code += '\tfont-size: 32px;\n';
		default_css_code += '\tcolor: #444;\n';
		default_css_code += '\ttext-align: center;\n';
		default_css_code += '\tfont-family:\'Open Sans\', Arial, Helvetica Neue, Helvetica, sans-serif;\n';
		default_css_code += '\tmargin-bottom: 15px;\n';
		default_css_code += '}\n';
		default_css_code += '.subtitle {\n';
		default_css_code += '\tfont-size: 18px;\n';
		default_css_code += '\tcolor: #666;\n';
		default_css_code += '\ttext-align: center;\n';
		default_css_code += '\tfont-family:Roboto, Arial, Helvetica Neue, Helvetica, sans-serif;\n';
		default_css_code += '\tmargin-top: 0px;\n';
		default_css_code += '\tmargin-bottom: 30px;\n';
		default_css_code += '}\n';
		default_css_code += '\n';
		default_css_code += '.cpalead-offers {\n';
		default_css_code += '\twidth: 100%;\n';
		default_css_code += '\tmargin: 0 auto;\n';
		default_css_code += '}\n';
		default_css_code += '\n';
		default_css_code += '.cpalead-offers-row {\n';
		default_css_code += '\ttext-align: center;\n';
		default_css_code += '}\n';
		default_css_code += '.cpalead-offers:after, .cpalead-offers-row:after {\n';
		default_css_code += '\tcontent: \"\";\n';
		default_css_code += '\tdisplay: block;\n';
		default_css_code += '\tclear: both;\n';
		default_css_code += '}\n';
		default_css_code += '\n';
		default_css_code += '.cpalead-offers-row a {\n';
		default_css_code += '\tdisplay: inline-block;\n';
		default_css_code += '\twidth: 240px;\n';
		default_css_code += '\theight: 60px;\n';
		default_css_code += '\tpadding: 3px 5px;\n';
		default_css_code += '\ttext-decoration: none;\n';
		default_css_code += '}\n';
		default_css_code += '\n';
		default_css_code += '.cpalead-offer-image {\n';
		default_css_code += '\tmargin: 5px auto;\n';
		default_css_code += '\tpadding-top: 1px;\n';
		default_css_code += '\twidth: 43px;\n';
		default_css_code += '\tfloat: left;\n';
		default_css_code += '\tpadding-left: 4px;\n';
		default_css_code += '\tpadding-right: 3px;\n';
		default_css_code += '}\n';
		default_css_code += '\n';
		default_css_code += '.cpalead-offer-image img {\n';
		default_css_code += '\twidth: 100%;\n';
		default_css_code += '\tborder-radius: 7px;\n';
		default_css_code += '\tborder: 0;\n';
		default_css_code += '}\n';
		default_css_code += '\n';
		default_css_code += '.cpalead-offer-content {\n';
		default_css_code += '\twidth: 72%;\n';
		default_css_code += '\tfloat: left;\n';
		default_css_code += '\tmargin: 0;\n';
		default_css_code += '\tpadding: 0;\n';
		default_css_code += '\ttext-align: left;\n';
		default_css_code += '\tmargin-top: 5px;\n';
		default_css_code += '\tmargin-left: 7px;\n';
		default_css_code += '}\n';
		default_css_code += '\n';
		default_css_code += '.cpalead-offer-content h3 {\n';
		default_css_code += '\tline-height: 16px;\n';
		default_css_code += '\tfont-size: 12px;\n';
		default_css_code += '\tpadding: 0px;\n';
		default_css_code += '\tmargin: 0;\n';
		default_css_code += '\tcolor: #044595;\n';
		default_css_code += '\tletter-spacing: 0px;\n';
		default_css_code += '\ttext-align: left;\n';
		default_css_code += '\tfont-family:Roboto, Arial, Helvetica Neue, Helvetica, sans-serif;\n';
		default_css_code += '}\n';
		default_css_code += '\n';
		default_css_code += '.cpalead-offer-content p {\n';
		default_css_code += '\tcolor: #666;\n';
		default_css_code += '\tmargin: 0;\n';
		default_css_code += '\tpadding: 2px 0;\n';
		default_css_code += '\tfont-size: 11px;\n';
		default_css_code += '\ttext-align: left;\n';
		default_css_code += '\tline-height: 1;\n';
		default_css_code += '\tfont-family:Roboto, Arial, Helvetica Neue, Helvetica, sans-serif;\n';
		default_css_code += '}';


		var default_ads_html = [];
		var default_ads_css = [];
		var default_ads_width = [];
		var default_ads_height = [];

		default_ads_css[0] =	'body { font-family:arial,sans-serif !important; font-size:14px; color:#333; margin:0; padding:0; }\n'+
		        				'a { text-decoration:none; word-break: break-word; }\n'+
		        				'h3 { text-align:center; }\n'+
		        				'ul { margin: 0; padding: 0; }\n'+
		        				'.clear { clear:both; } \n'+
        						'a:focus { outline: none; }\n'+
        						'img { border-radius: 10px; }\n'+
							    '.gradient-effect, .gradient-effect2 { background: #f5f5f5; }\n';

		default_ads_html[1] = 	'<div class="bar336">\n'+
			                    '\t<a href="{offer_link}" data-orig-href="{offer_link}" target="_blank">\n'+
			                    '\t\t<div class="row-bar gradient-effect">\n'+
			                    '\t\t\t<h3>{offer_title}</h3>\n'+
			                    '\t\t\t<p>{offer_description_1}</p>\n'+
			                    '\t\t\t<p>{offer_description_2}</p>\n'+
			                    '\t\t\t<br>\n'+
			                    '\t\t\t<div class="pic-box">\n'+
			                    '\t\t\t\t<img src="{offer_image}" border="0">\n'+
			                    '\t\t\t</div>\n'+
			                    '\t\t</div>\n'+
			                    '\t</a>\n</div>';
		default_ads_css[1] =	default_ads_css[0] + '.bar336 { width:334px;height:278px;margin: 0 auto; overflow:hidden; }\n'+
			        			'.row-bar { width:334px; height:278px; border:1px solid #CCC; margin:0 auto; text-align:center; }\n'+
			       				'.row-bar h3 { font-size:20px; padding:20px 0 5px; margin:0; color: #044595; }\n'+
			     				'.row-bar p { color:#666; margin:0; padding:0 25px;font-weight:600; }\n'+
			       				'.pic-box { margin:10px auto 0; padding:0; width:125px; height:125px; }\n'+
			        			'.pic-box img { width:100%; border: solid #eee 2px; }';
		default_ads_width[1] = '336';
		default_ads_height[1] = '280';

        default_ads_html[2] = 	'<div class="bar300">\n'+
		                        '\t<a href="{offer_link}" data-orig-href="{offer_link}" target="_blank">\n'+
		                        '\t\t<div class="row-bar-01 gradient-effect">\n'+
		                        '\t\t\t<h3>{offer_title}</h3>\n'+
		                        '\t\t\t<p>{offer_description_1}</p>\n'+
		                        '\t\t\t<p>{offer_description_2}</p>\n'+
		                        '\t\t\t<br>\n'+
		                        '\t\t\t<div class="pic-box-01">\n'+
		                        '\t\t\t\t<img src="{offer_image}" border="0">\n'+
		                        '\t\t\t</div>\n'+
		                        '\t\t</div>\n'+
		                        '\t</a>\n'+
		                        '</div>';
		default_ads_css[2] =	default_ads_css[0] + 	'.bar300 { width:298px;height:248px;margin: 0 auto; overflow:hidden; }\n'+
        						'.row-bar-01 { width:300px; height:250px; border:1px solid #CCC; margin:0 auto; text-align:center; }\n'+
        						'.row-bar-01 h3 { font-size:18px; padding:20px 0 5px; margin:0; color: #044595;font-weight:600; }\n'+
        						'.row-bar-01 p { color:#666; margin:0; padding:0 15px;font-weight:600; }\n'+
        						'.pic-box-01 { margin:10px auto 0; padding:0; width:125px; height:125px; }\n'+
        						'.pic-box-01 img { width:100%; border: solid #eee 2px;border-radius: 15px; }';
		default_ads_width[2] = '300';
		default_ads_height[2] = '250';

        default_ads_html[3] = 	'<div class="ad-row-bar-2 gradient-effect">\n';
		        				for(i=0; i < 3; i++) {
		        					default_ads_html[3] += '\t<a href="{offer_link}" target="_blank">\n'+
			                        '\t\t<div class="bar1">\n'+
			                        '\t\t\t<div class="ad-pic-box-2">\n'+
			                        '\t\t\t\t<img src="{offer_image}" border="0">\n'+
			                        '\t\t\t</div>\n'+
			                        '\t\t\t<div class="ad-row-contant">\n'+
			                        '\t\t\t\t<h3>{offer_title}</h3>\n'+
			                        '\t\t\t\t<p>{offer_description_1}</p>\n'+
			                        '\t\t\t\t<p>{offer_description_2}</p>\n'+
			                        '\t\t\t</div>\n'+
			                        '\t\t\t<div class="clear"></div>\n'+
			                        '\t\t</div>\n'+
			                        '\t</a>\n'; 
			                    }
			                    default_ads_html[3] += '\t<div class="clear"></div>\n</div>';
		default_ads_css[3] =	default_ads_css[0] + 	'.ad-row-bar-2 { width:726px; height:88px; border:1px solid #CCC; margin:0 auto; overflow:hidden; text-align: center;}\n'+
								'.ad-row-bar-2>a { display: inline-block; width: 230px; margin: 13px 0 0 5px; text-align: left;}\n'+
								'.ad-row-contant { width: 75%; padding: 0px 3px; float: left; margin-top: 5px; margin-left: 10px; }\n'+
								'.ad-row-contant h3 { font-size:12px; padding:0px; margin:0; color: #044595; text-align:left; letter-spacing:0px; }\n'+
								'.ad-row-contant p { color:#666; margin:0; font-size:10px;overflow: auto; }\n'+
								'.ad-pic-box-2 { margin:5px auto ; padding-top:1px; width:50px; float:left; }\n'+
								'.ad-pic-box-2 img { width:100%;border-radius:5px; }\n'+
								'.bar1 .ad-row-contant { width: 155px; margin-top: 0px; }';
		default_ads_width[3] = '728';
		default_ads_height[3] = '90';


        default_ads_html[4] = 	'<div class="ad-row-bar-03">\n<div>\n';
		        				for(i=0; i < 8; i++) {
			        				default_ads_html[4] += '\t<a href="{offer_link}" target="_blank">\n'+
			                        '\t\t<div class="bar2 gradient-effect2">\n'+
			                        '\t\t\t<div class="ad-pic-box-2">\n\t\t\t\t<img src="{offer_image}" border="0">\n\t\t\t</div>\n'+
			                        '\t\t\t<div class="ad-row-contant">\n'+
			                        '\t\t\t\t<h3>{offer_title}</h3>\n'+
			                        '\t\t\t\t<p>{offer_description_1}</p>\n'+
			                        '\t\t\t\t<p>{offer_description_2}</p>\n'+
			                        '\t\t\t</div>\n'+
			                        '\t\t\t<div class="clear"></div>\n'+
			                        '\t\t</div>\n'+
			                        '\t</a>\n'; 
		                       	}
		                        default_ads_html[4] += '<div>\n</div>';
		default_ads_css[4] =	default_ads_css[0] + 	'.ad-row-bar-03 { width:298px; height:598px; border:1px solid #CCC; margin:0 auto; background:#f5f5f5; overflow:hidden; display: flex; }\n'+
								'.ad-row-bar-03>div { width: 100%; margin: auto auto; }\n'+
        						'.ad-row-bar-03>div>a { display: block; }\n'+
        						'.bar2 { width:90%; margin:5px auto; padding:0px 5px 2px; background: #f5f5f5; }\n'+
								'.ad-pic-box-2 { margin:5px auto ; padding-top:1px; width:50px; float:left; }\n'+
        						'.ad-pic-box-2 img { width:100%;border-radius:5px; } \n'+
								'.ad-row-contant { width: 75%; padding: 0px 3px; float: left; margin-top: 5px; margin-left: 10px; }\n'+
								'.ad-row-contant h3 { font-size:12px; padding:0px; margin:0; color: #044595; text-align:left; letter-spacing:0px; }\n'+
								'.ad-row-contant p { color:#666; margin:0; font-size:10px;overflow: auto; }';
		default_ads_width[4] = '300';
		default_ads_height[4] = '600';




        default_ads_html[5] = 	'<div class="ad-row-bar-4 gradient-effect">\n\t<a href="{offer_link}" target="_blank">\n'+
		                        '\t\t<div class="bar-3">\n'+
		                        '\t\t\t<div class="ad-pic-box-2">\n\t\t\t\t<img src="{offer_image}" border="0">\n\t\t\t</div>\n'+
		                        '\t\t\t<div class="ad-row-contant">\n'+
		                        '\t\t\t\t<h3>{offer_title}</h3>\n'+
		                        '\t\t\t\t<p>{offer_description_1}</p>\n'+
		                        '\t\t\t\t<p>{offer_description_2}</p>\n'+
		                        '\t\t\t</div>\n'+
		                        '\t\t\t<div class="clear"></div>\n'+
		                        '\t\t</div>\n'+
		                        '\t</a>\n</div>';
		default_ads_css[5] =	default_ads_css[0] + 	'.ad-row-bar-4 { width:298px; hidden:98px; border:1px solid #CCC; margin:0 auto; overflow:hidden; }\n'+
        						'.bar-3 { width:90%; margin:5px auto; padding:5px 5px 2px; }\n'+
        						'.ad-bar-1 { width:466px; height:58px; border:1px solid #CCC; margin:0 auto; overflow:hidden; text-align: center; }\n'+
								'.ad-bar-1>a { display: inline-block; width: 215px; margin: 0 5px 0 10px; padding: 10px 0px 5px; text-align: left;}\n'+
								'.ad-pic-box-2 { margin:5px auto ; padding-top:1px; width:50px; float:left; }\n'+
        						'.ad-pic-box-2 img { width:100%;border-radius:5px; }\n'+
        						'.ad-row-contant { width: 75%; padding: 0px 3px; float: left; margin-top: 5px; margin-left: 10px; }\n'+
        						'.ad-row-contant h3 { font-size:12px; padding:0px; margin:0; color: #044595; text-align:left; letter-spacing:0px; }\n'+
								'.ad-row-contant p { color:#666; margin:0; font-size:10px;overflow: auto; }\n'+
								'.ad-cont-1 { width: 160px; margin: 0; padding: 0px 0px 0px 12px; vertical-align: top; float: left; }\n'+
								'.ad-cont-1 h3 { line-height: 12px;font-size:12px; padding:0px; margin:0; color: #044595; text-align:left; letter-spacing:0px; }\n'+
								'.ad-cont-1 p { color:#666; margin:0; padding:2px 0; font-size:10px; }';
		default_ads_width[5] = '300';
		default_ads_height[5] = '100';


		default_ads_html[6] = 	'<div class="ad-bar-1 gradient-effect">\n';
		        				for(i=0; i < 2; i++) {
			        				default_ads_html[6] += '\t<a href="{offer_link}" target="_blank">\n'+
			                        '\t\t<div class="cont-bar-1">\n'+
			                        '\t\t\t<div class="pic-box-1">\n\t\t\t\t<img src="{offer_image}" border="0">\n\t\t\t</div>\n'+
			                        '\t\t\t<div class="ad-cont-1">\n'+
			                        '\t\t\t\t<h3>{offer_title}</h3>\n'+
			                        '\t\t\t\t<p>{offer_description_1}</p>\n'+
			                        '\t\t\t</div>\n'+
			                        '\t\t\t<div class="clear"></div>\n'+
			                        '\t\t</div>\n'+
			                        '\t</a>\n'; 
			                    } 
		                        default_ads_html[6] += '\t<div class="clear"></div>\n</div>';
		default_ads_css[6] =	default_ads_css[0] + '.ad-bar-1 { width:466px; height:58px; border:1px solid #CCC; margin:0 auto; overflow:hidden; text-align: center; }\n'+
								'.ad-bar-1>a { display: inline-block; width: 215px; margin: 0 5px 0 10px; padding: 10px 0px 5px; text-align: left;}\n'+
        						'.pic-box-1 { margin:0px auto ; padding:0; width:40px; height:45px; float:left; }\n'+
        						'.pic-box-1 img { width:100%; }\n'+
        						'.ad-cont-1 { width: 160px; margin: 0; padding: 0px 0px 0px 12px; vertical-align: top; float: left; }\n'+
								'.ad-cont-1 h3 { line-height: 12px;font-size:12px; padding:0px; margin:0; color: #044595; text-align:left; letter-spacing:0px; }\n'+
								'.ad-cont-1 p { color:#666; margin:0; padding:2px 0; font-size:10px; }';
		default_ads_width[6] = '468';
		default_ads_height[6] = '60';


        default_ads_html[7] =   '<div class="ad-bar-2 gradient-effect">\n'+
        						'\t<a href="{offer_link}" target="_blank">\n'+
		                        '\t\t<div class="cont-bar-2">'+
		                        '\t\t\t<div class="pic-box-2">\n\t\t\t\t<img src="{offer_image}" border="0">\n\t\t\t</div>\n'+
		                        '\t\t\t<div class="ad-cont-2">\n'+
		                        '\t\t\t\t<h3>{offer_title}</h3>\n'+
		                        '\t\t\t\t<p>{offer_description_1}</p>\n'+
		                        '\t\t\t\t<p>{offer_description_2}</p>\n'+
		                        '\t\t\t</div>\n'+
		                        '\t\t\t<div class="clear"></div>\n'+
		                        '\t\t</div>\n'+
		                        '\t</a>\n'+
		                        '</div>'; 
		default_ads_css[7] =	default_ads_css[0] + '.ad-bar-2 { width:248px; height:248px; border:1px solid #CCC; margin:0 auto; text-align:center; overflow:hidden; }\n'+
								'.cont-bar-2 { margin:0px; padding:10px 0px; }\n'+
								'.pic-box-2 { margin: 15px 0;padding:0;width: 125px;display:inline-block; }\n'+
        						'.pic-box-2 img { width:100%; }\n'+
								'.ad-cont-2 {margin:0;padding:0 5px;text-align: center; }\n'+
						        '.ad-cont-2 h3 { font-size: 16px;padding-bottom:5px;margin:0;color: #044595;letter-spacing:0px; }\n'+
						        '.ad-cont-2 p { color:#666; margin:0; padding:2px 0; font-size:12px; font-weight:600; }';
		default_ads_width[7] = '250';
		default_ads_height[7] = '250';



		default_ads_html[8] = 	'<div class="ad-bar-3">\n<div>\n';
		        				for(i=0; i < 5; i++) {
			        				default_ads_html[8] += '\t<a href="{offer_link}" target="_blank">\n'+
			                        '\t\t<div class="bar3 gradient-effect2">\n'+
			                        '\t\t\t<div class="pic-box-3">\n\t\t\t\t<img src="{offer_image}" border="0">\n\t\t\t\t<br>\n\t\t\t</div>\n'+
			                        '\t\t\t<div class="ad-cont-3">\n'+
			                        '\t\t\t\t<h3>{offer_title}</h3>\n'+
			                        '\t\t\t\t<p>{offer_description_1}</p>\n'+
			                        '\t\t\t</div>\n'+
			                        '\t\t\t<div class="clear"></div>\n'+
			                        '\t\t</div>\n'+
			                        '\t</a>\n'; 
			                    }
		                        default_ads_html[8] += '</div>\n</div>';
		default_ads_css[8] =	default_ads_css[0] + '.ad-bar-3 { width:158px; height:598px; border:1px solid #CCC; margin:0 auto; background: #f5f5f5;text-align: center; overflow:hidden; display: flex; }\n'+
								'.ad-bar-3>div { width: 100%; margin: auto auto; }\n'+
        						'.ad-bar-3>div>a { display: block; }\n'+
						        '.ad-cont-3 h3 { line-height: 12px;font-size: 10px;padding: 0px;margin: 0;color: #044595;letter-spacing: 0px; }\n'+
						        '.ad-cont-3 p { line-height:12px;color: #666; margin: 0; padding: 2px 0; font-size: 9px; font-weight: bold; }\n'+
						        '.cont-bar-3 { margin: 0px auto; padding: 10px 0px; width: 93%; }\n'+
						        '.pic-box-3 { margin: 8px auto 4px;padding: 0;width: 55px;text-align: center; }\n'+
						        '.pic-box-3 img { width:100%; }  \n'+
						        '.ad-cont-3 { margin: 0;padding: 0;display: inline-block;text-align: center; }\n'+
						        '.bar3 { width:95%;margin: 5px auto 0px;padding:1px 0px 2px; text-align: center; }\n';
		default_ads_width[8] = '160';
		default_ads_height[8] = '600';


		default_ads_html[9] = 	'<div class="ad-bar-4">\n<div>\n';
			        				for(i=0; i < 4; i++) {
				        				default_ads_html[9] += '\t<a href="{offer_link}" target="_blank">\n'+
				                        '\t\t<div class="bar4 gradient-effect2">\n'+
				                        '\t\t\t<div class="pic-box-4">\n\t\t\t\t<img src="{offer_image}" border="0">\n\t\t\t</div>\n'+
				                        '\t\t\t<div class="ad-cont-4">\n'+
				                        '\t\t\t\t<h3>{offer_title}</h3>\n'+
				                        '\t\t\t\t<p>{offer_description_1}</p>\n'+
				                        '\t\t\t</div>\n'+
				                        '\t\t\t<div class="clear"></div>\n'+
				                        '\t\t</div>\n'+
				                        '\t</a>\n';
				                    }
			                        default_ads_html[9] += '</div>\n</div>';
		default_ads_css[9] =	default_ads_css[0] + '.ad-bar-4 { width:118px; height:598px; border:1px solid #CCC; margin:0 auto; background: #f5f5f5; overflow:hidden; display: flex; }\n'+
								'ad-bar-4>div { width: 100%; margin: auto auto; }\n'+
        						'.ad-bar-4>div>a { display: block; }\n'+
						        '.ad-cont-4 h3 { line-height: 12px;font-size: 9px;padding: 0px;margin: 0;color: #044595;letter-spacing: 0px; }\n'+
						        '.ad-cont-4 p { color: #666; margin: 0; padding: 2px 0; font-size: 10px; }\n'+
						        '.cont-bar-4 { margin: 0px auto; padding: 10px 0px; width: 93%; }\n'+
						        '.pic-box-4 { margin: 8px auto 0;padding: 0;width: 65px;display:}\n'+
						        '.pic-box-4 img { width:100%;border-radius:9px; }\n'+
						        '.ad-cont-4 { margin: 0;padding: 0;display: inline-block;text-align: center; }\n'+
						        '.bar4 { width:93%;margin: 30px auto 15px;padding:0px 0px 0px; text-align: center; }\n';
		default_ads_width[9] = '120';
		default_ads_height[9] = '600';


		default_ads_html[10] = 	'<div class="ad-bar-5 gradient-effect">\n'+
								'\t<a href="{offer_link}" target="_blank">\n'+
		                        '\t\t<div class="cont-bar-5">\n'+
		                        '\t\t\t<div class="pic-box-5">\n\t\t\t\t<img src="{offer_image}" border="0">\n\t\t\t</div>\n'+
		                        '\t\t\t<div class="ad-cont-5">\n'+
		                        '\t\t\t\t<h3>{offer_title}</h3>\n'+
		                        '\t\t\t\t<p>{offer_description_1}</p>\n'+
		                        '\t\t\t</div>\n'+
		                        '\t\t\t<div class="clear"></div>\n'+
		                        '\t\t</div>\n'+
		                        '\t</a>\n'+
		                        '</div>';
		default_ads_css[10] =	default_ads_css[0] + '.ad-bar-5 { width:118px; height:238px; border:1px solid #CCC; margin:0 auto; text-align:center; overflow:hidden; }\n'+
        						'.pic-box-5 { margin: 5px 0;padding:0;width: 80px;display:inline-block; }\n'+
        						'.pic-box-5 img { width:100%; }\n'+
        						'.ad-cont-5 { margin:0;padding: 0 3px;text-align: center; }\n'+
        						'.ad-cont-5 h3 { font-size: 16px;padding:0px;margin:0;color: #044595;letter-spacing:1px; }\n'+
        						'.ad-cont-5 p { color:#666;margin:0;padding: 5px 0;font-size: 11px;font-weight:bold; }\n'+
        						'.cont-bar-5 { margin:0px;padding: 40px 0px; }';
		default_ads_width[10] = '120';
		default_ads_height[10] = '240';


		default_ads_html[11] = 	'<div class="ad-bar-6 gradient-effect">\n<div>\n';
		        				for(i=0; i < 6; i++) {
			        				default_ads_html[11] += '\t<a href="{offer_link}" target="_blank">\n'+
			                        '\t\t<div class="bar6">\n'+
			                        '\t\t\t<div class="pic-box-6">\n\t\t\t\t<img src="{offer_image}" border="0">\n\t\t\t</div>\n'+
			                        '\t\t\t<div class="ad-cont-6">\n'+
			                        '\t\t\t\t<h3>{offer_title}</h3>\n'+
			                        '\t\t\t\t<p>{offer_description_1}</p>\n'+
			                        '\t\t\t\t<p>{offer_description_2}</p>\n'+
			                        '\t\t\t</div>\n'+
			                        '\t\t</div>\n'+
			                        '\t</a>\n';
			                    } 
		                        default_ads_html[11] += '</div>\n</div>';
		default_ads_css[11] =	default_ads_css[0] + '.ad-bar-6 { width: 238px;height: 398px;border:1px solid #CCC;margin:0 auto;background:#f5f5f5; overflow:hidden; overflow:hidden; display: flex; }\n'+
								'ad-bar-6>div { width: 100%; margin: auto auto; }\n'+
        						'.ad-bar-6>div>a { display: block; }\n'+
        						'.ad-cont-6 h3 { line-height: 16px;font-size: 12px;padding: 0px;margin: 0;color: #044595;letter-spacing: 0px;text-align: left; }\n'+
        						'.ad-cont-6 p { color: #666;margin: 0;padding: 2px 0;font-size: 10px;text-align: left; font-weight:600;line-height: 1; }\n'+
        						'.cont-bar-6 { margin: 0px auto; padding: 10px 0px; }\n'+
        						'.pic-box-6 { margin:5px auto ; padding-top:1px; width:43px; float:left; padding-left: 4px; padding-right:3px; }\n'+
        						'.pic-box-6 img { width:100%; border-radius:7px; }\n'+
        						'.ad-cont-6 { width: 72%; float: left; margin: 0; padding: 0; text-align: left; margin-top: 0px; margin-left: 10px; }\n'+
        						'.bar6 { width: 100%; margin: 0px auto; padding: 3px 5px; display: inline-block; float: left; }';
		default_ads_width[11] = '240';
		default_ads_height[11] = '400';

	
		default_ads_html[12] = 	'<div class="ad-bar-7 gradient-effect">\n'+
								'\t<a href="{offer_link}" target="_blank">\n'+
		                        '\t\t<div class="bar7">\n'+
		                        '\t\t\t<div class="pic-box-7">\n\t\t\t\t<img src="{offer_image}" border="0">\n\t\t\t</div>\n'+
		                        '\t\t\t<div class="ad-cont-7">\n'+
		                        '\t\t\t\t<h3>{offer_title}</h3>\n'+
		                        '\t\t\t\t<p>{offer_description_1}</p>\n'+
		                        '\t\t\t</div>\n'+
		                        '\t\t\t<div class="clear"></div>\n'+
		                        '\t\t</div>\n'+
		                        '\t</a>\n'+
		                        '</div>\n';
		default_ads_css[12] =	default_ads_css[0] + '.ad-bar-7 { width: 232px; height: 58px;border:1px solid #CCC;margin:0 auto;background:#f5f5f5; overflow:hidden; }\n'+
        						'.ad-cont-7 h3 { line-height: 16px;font-size: 12px;padding: 0px;margin: 0;color: #044595;letter-spacing: 0px;text-align: left; }\n'+
        						'.ad-cont-7 p { line-height: 12px;color: #666;margin: 0;padding: 2px 0;font-size: 10px; }\n'+
        						'.cont-bar-7 { margin: 0px auto; padding: 10px 0px; width: 93%; }\n'+
        						'.pic-box-7 { margin-top: 3px;padding-left:1px;border-radius: 6px; width: 40px;float: left;display:inline-block; }\n'+
        						'.pic-box-7 img { width:100%;border-radius: 6px; }\n'+
        						'.ad-cont-7 { width: 175px; margin: 0; padding-left: 12px; float: left; text-align: left; }\n'+
        						'.bar7 { width: 100%;margin: 2px auto; padding: 4px 8px; display: inline-block;text-align:center;float:left; }';
		default_ads_width[12] = '234';
		default_ads_height[12] = '60';


		default_ads_html[13] = 	'<div class="ad-bar-8 gradient-effect">\n'+
								'\t<a href="{offer_link}" target="_blank">\n'+
		                        '\t\t<div class="cont-bar-8">\n'+
		                        '\t\t\t<div class="pic-box-8">\n\t\t\t\t<img src="{offer_image}" border="0">\n\t\t\t</div>\n'+
		                        '\t\t\t<div class="ad-cont-8">\n'+
		                        '\t\t\t\t<h3>{offer_title}</h3>\n'+
		                        '\t\t\t\t<p>{offer_description_1}</p>\n'+
		                        '\t\t\t</div>\n'+
		                        '\t\t\t<div class="clear"></div>\n'+
		                        '\t\t</div>\n'+
		                        '\t</a>\n'+
		                        '</div>';
		default_ads_css[13] =	default_ads_css[0] + '.ad-bar-8 { width:178px; height:148px; border:1px solid #CCC; margin:0 auto; text-align:center; overflow:hidden; }\n'+
						        '.pic-box-8 { margin: 8px 0;padding:0;width: 50px;display:inline-block; }\n'+
						        '.pic-box-8 img { width:100%; }\n'+
						        '.ad-cont-8 { margin:0;padding: 0 2px;text-align: center; }\n'+
						        '.ad-cont-8 h3 { line-height: 16px;font-size: 14px;padding:0px;margin:0;color: #044595;letter-spacing:0px; }\n'+
						        '.ad-cont-8 p { color:#666;margin:0;padding: 5px 0;font-size: 12px; }\n'+
						        '.cont-bar-8 { margin:0px;padding: 14px 2px; }';
		default_ads_width[13] = '180';
		default_ads_height[13] = '150';


		default_ads_html[14] = 	'<div class="ad-bar-9 gradient-effect">\n'+
								'\t<a href="{offer_link}" target="_blank">\n'+
		                        '\t\t<div class="cont-bar-9">\n'+
		                        '\t\t\t<div class="pic-box-9">\n\t\t\t\t<img src="{offer_image}" border="0">\n\t\t\t</div>\n'+
		                        '\t\t\t<div class="ad-cont-9">\n'+
		                        '\t\t\t\t<h3>{offer_title}</h3>\n'+
		                        '\t\t\t\t<p>{offer_description_1}</p>\n'+
		                        '\t\t\t</div>\n'+
		                        '\t\t\t<div class="clear"></div>\n'+
		                        '\t\t</div>\n'+
		                        '\t</a>\n'+
		                        '</div>';
		default_ads_css[14] =	default_ads_css[0] + '.ad-bar-9 { width:123px; height:123px; border:1px solid #CCC; margin:0 auto; text-align:center; overflow:hidden; }\n'+
						        '.pic-box-9 { margin: 5px 0 2px;padding:0;width: 50px;display:inline-block; }\n'+
						        '.pic-box-9 img { width:100%; }\n'+
						        '.ad-cont-9 { margin:0;padding: 0 2px;text-align: center; }\n'+
						        '.ad-cont-9 h3 { font-size: 10px;padding:0px;margin:0;color: #044595;letter-spacing:0px;line-height: 12px; }\n'+
						        '.ad-cont-9 p { line-height: 12px;color:#666;margin:0;padding: 1px 0;font-size: 9px;font-weight:bold; }\n'+
						        '.cont-bar-9 { margin:0px;padding: 14px 2px; }';
		default_ads_width[14] = '125';
		default_ads_height[14] = '125';

			
		default_ads_html[15] = 	'<div class="ad-bar-0">\n<div>\n';
		        				for(i=0; i < 2; i++) {
			        				default_ads_html[15] += '\t<a href="{offer_link}" target="_blank">\n'+
			                        '\t\t<div class="bar0 gradient-effect2">\n'+
			                        '\t\t\t<div class="pic-box-0">\n\t\t\t\t<img src="{offer_image}" border="0">\n\t\t\t</div>\n'+
			                        '\t\t\t<div class="ad-cont-0">\n'+
			                        '\t\t\t\t<h3>{offer_title}</h3>\n'+
			                        '\t\t\t\t<p>{offer_description_1}</p>\n'+
			                        '\t\t\t</div>\n'+
			                        '\t\t\t<div class="clear"></div>\n'+
			                        '\t\t</div>\n'+
			                        '\t</a>\n';
			                    }
		                        default_ads_html[15] += '</div>\n</div>';
		default_ads_css[15] =	default_ads_css[0] + '.ad-bar-0 { width:118px; height:238px; border:1px solid #CCC; margin:0 auto; background:#f5f5f5; overflow:hidden; display: flex; }\n'+
								'ad-bar-0>div { width: 100%; margin: auto auto; }\n'+
        						'.ad-bar-0>div>a { display: block; }\n'+
								'.ad-cont-0 h3 { line-height: 12px;font-size: 10px;padding: 0px;margin: 0;color: #044595;letter-spacing: 0px; }\n'+
								'.ad-cont-0 p { line-height: 12px;color: #666; margin: 0; padding: 2px 0; font-size: 9px; font-weight: bold; }\n'+
								'.cont-bar-0 { margin: 0px auto; padding: 10px 0px; width: 93%; }\n'+
								'.pic-box-0 { margin: 0px;padding: 0;width: 45px;display: inline-block; }\n'+
								'.pic-box-0 img { width:100%; }\n'+
								'.ad-cont-0 { margin: 0;padding: 0;display: block; text-align: center; }\n'+
								'.bar0 { width: 93%; margin: 5px auto 5px; padding: 10px 0px 0px; text-align: center; }';
		default_ads_width[15] = '120';
		default_ads_height[15] = '240';

